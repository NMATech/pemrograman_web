<?php

// Sambungkan php dan mysqli mysqli(nama host, username db, pass db, nama db)
$db = mysqli_connect("localhost", "root", "", "perpustakaan") or die ("Gagal terkoneksi ke database");

